'use client'

import { cn } from '@/lib/utils'

export interface ReflectionSectionProps {
  title?: string
  subtitle?: string
  quote?: string
  author?: string
  content?: string
  alignment?: 'left' | 'center' | 'right'
  variant?: 'default' | 'muted' | 'bordered'
}

export function ReflectionSection({
  title,
  subtitle,
  quote,
  author,
  content,
  alignment = 'center',
  variant = 'default',
}: ReflectionSectionProps) {
  const alignmentClasses = {
    left: 'text-left items-start',
    center: 'text-center items-center',
    right: 'text-right items-end',
  }

  const variantClasses = {
    default: 'bg-background',
    muted: 'bg-muted/30',
    bordered: 'border-y border-border/50 bg-muted/20',
  }

  return (
    <section
      className={cn(
        "py-16 md:py-24 px-4 md:px-8",
        variantClasses[variant]
      )}
    >
      <div
        className={cn(
          "container mx-auto max-w-4xl space-y-8",
          alignmentClasses[alignment]
        )}
      >
        {/* Quote */}
        {quote && (
          <blockquote className="space-y-4">
            <p className="font-zen-serif text-xl md:text-3xl tracking-wide text-foreground leading-relaxed">
              {quote}
            </p>
            {author && (
              <footer className="font-zen-sans text-sm text-muted-foreground italic">
                — {author}
              </footer>
            )}
          </blockquote>
        )}

        {/* Title and Subtitle */}
        {(title || subtitle) && (
          <div className="space-y-4">
            {subtitle && (
              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                {subtitle}
              </p>
            )}
            {title && (
              <h2 className="font-zen-serif text-2xl md:text-4xl tracking-wide text-foreground">
                {title}
              </h2>
            )}
          </div>
        )}

        {/* Content */}
        {content && (
          <div className="prose prose-lg max-w-none">
            <p className="font-zen-sans text-base md:text-lg text-muted-foreground leading-relaxed whitespace-pre-line">
              {content}
            </p>
          </div>
        )}
      </div>
    </section>
  )
}
