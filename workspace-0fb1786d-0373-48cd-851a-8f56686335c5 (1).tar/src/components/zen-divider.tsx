import { cn } from '@/lib/utils'

export interface ZenDividerProps {
  className?: string
  variant?: 'solid' | 'gradient' | 'double'
  spacing?: 'none' | 'small' | 'medium' | 'large'
}

export function ZenDivider({
  className,
  variant = 'gradient',
  spacing = 'medium',
}: ZenDividerProps) {
  const spacingClasses = {
    none: 'my-0',
    small: 'my-4',
    medium: 'my-8',
    large: 'my-16',
  }

  const variantStyles = {
    solid: 'bg-border',
    gradient: 'bg-gradient-to-r from-transparent via-border to-transparent',
    double:
      'bg-gradient-to-r from-transparent via-border to-transparent relative before:absolute before:inset-0 before:bg-border before:opacity-0',
  }

  return (
    <div
      className={cn(
        "w-full h-px",
        spacingClasses[spacing],
        variantStyles[variant],
        className
      )}
    />
  )
}
