'use client'

import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { BookOpen, Clock, Users } from 'lucide-react'

export interface ScriptureCardProps {
  id: string
  title: string
  subtitle?: string
  description: string
  category?: string
  duration?: string
  students?: number
  image?: string
  featured?: boolean
}

export function ScriptureCard({
  id,
  title,
  subtitle,
  description,
  category,
  duration,
  students,
  image,
  featured = false,
}: ScriptureCardProps) {
  return (
    <Link href={`/kinh-bo/${id}`}>
      <Card
        className={cn(
          "group h-full overflow-hidden border-border/50 bg-card/50 backdrop-blur zen-card-hover",
          featured && "border-primary/30"
        )}
      >
        {/* Image Section */}
        {image && (
          <div className="relative h-48 overflow-hidden bg-muted/20">
            <img
              src={image}
              alt={title}
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            {category && (
              <div className="absolute top-3 left-3">
                <Badge
                  variant="secondary"
                  className="font-zen-serif text-xs tracking-wider bg-background/80 backdrop-blur"
                >
                  {category}
                </Badge>
              </div>
            )}
          </div>
        )}

        {/* Content Section */}
        <div className="p-6 space-y-4">
          {/* Title */}
          <div className="space-y-1">
            {subtitle && (
              <p className="font-zen-serif text-xs tracking-widest text-muted-foreground uppercase">
                {subtitle}
              </p>
            )}
            <h3 className="font-zen-serif text-lg tracking-wide group-hover:text-primary transition-colors">
              {title}
            </h3>
          </div>

          {/* Description */}
          <p className="font-zen-sans text-sm text-muted-foreground line-clamp-3 leading-relaxed">
            {description}
          </p>

          {/* Metadata */}
          <div className="flex items-center space-x-4 pt-2 border-t border-border/50">
            {duration && (
              <div className="flex items-center space-x-1.5 text-xs text-muted-foreground">
                <Clock className="h-3.5 w-3.5" />
                <span className="font-zen-sans">{duration}</span>
              </div>
            )}
            {students && (
              <div className="flex items-center space-x-1.5 text-xs text-muted-foreground">
                <Users className="h-3.5 w-3.5" />
                <span className="font-zen-sans">{students}</span>
              </div>
            )}
            <div className="flex items-center space-x-1.5 text-xs text-muted-foreground ml-auto">
              <BookOpen className="h-3.5 w-3.5" />
              <span className="font-zen-sans">Xem thêm</span>
            </div>
          </div>
        </div>
      </Card>
    </Link>
  )
}
