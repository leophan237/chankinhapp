import Link from 'next/link'
import { Separator } from '@/components/ui/separator'

export function ZenFooter() {
  return (
    <footer className="mt-auto border-t border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 md:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img
              src="/logo.png"
              alt="Chân Kinh Online Logo"
              className="h-8 w-auto"
            />
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-6">
            <Link
              href="/tong-chi"
              className="font-zen-serif text-xs tracking-wider text-muted-foreground hover:text-foreground transition-colors"
            >
              Tông Chỉ
            </Link>
            <Separator orientation="vertical" className="h-4" />
            <Link
              href="/kinh-cac"
              className="font-zen-serif text-xs tracking-wider text-muted-foreground hover:text-foreground transition-colors"
            >
              Kinh Các
            </Link>
            <Separator orientation="vertical" className="h-4" />
            <Link
              href="/dao-trang"
              className="font-zen-serif text-xs tracking-wider text-muted-foreground hover:text-foreground transition-colors"
            >
              Đạo Tràng
            </Link>
          </div>

          {/* Copyright */}
          <p className="font-zen-sans text-xs text-muted-foreground">
            © 2024 Chân Kinh Online
          </p>
        </div>

        <div className="mt-6 pt-6 border-t border-border/50 text-center">
          <p className="font-zen-serif text-xs tracking-wider text-muted-foreground italic">
            "Knowledge flows when the mind is still"
          </p>
        </div>
      </div>
    </footer>
  )
}
