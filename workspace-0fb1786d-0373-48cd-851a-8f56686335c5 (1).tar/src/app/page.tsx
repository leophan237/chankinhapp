'use client'

import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ReflectionSection } from '@/components/reflection-section'
import { ZenDivider } from '@/components/zen-divider'
import { ScriptureCard } from '@/components/scripture-card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

// Sample data - will be replaced with API data later
const featuredCourses = [
  {
    id: '1',
    title: 'Đạo Đức Kinh',
    subtitle: 'Kinh điển cơ bản',
    description:
      'Khởi hành từ những lời dạy cơ bản về đạo đức và lối sống. Một hành trình khám phá bản chất của tâm trí và hành vi con người.',
    category: 'Kinh điển',
    duration: '8 tuần',
    students: 128,
    image: null,
  },
  {
    id: '2',
    title: 'Thiền Định Nhập Môn',
    subtitle: 'Thực hành tâm linh',
    description:
      'Học cách an trú trong hiện tại và phát triển sự tỉnh thức. Những kỹ thuật thiền định cơ bản cho người mới bắt đầu.',
    category: 'Thực hành',
    duration: '6 tuần',
    students: 96,
    image: null,
  },
  {
    id: '3',
    title: 'Bát Chánh Đạo',
    subtitle: 'Hành trình giác ngộ',
    description:
      'Mười sáu bài học về con đường Trung Đạo. Một hệ thống hoàn chỉnh để hiểu rõ bản chất của khổ đau và sự giải thoát.',
    category: 'Kinh điển',
    duration: '16 tuần',
    students: 243,
    image: null,
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center px-4 md:px-8 overflow-hidden">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img
              src="/images/zen-hero.jpg"
              alt="Zen meditation garden"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/80 to-background" />
          </div>

          {/* Content */}
          <div className="relative z-10 container mx-auto max-w-4xl text-center space-y-12">
            {/* Zen Symbol */}
            <div className="flex justify-center">
              <img
                src="/logo-square.jpg"
                alt="Chân Kinh Online Symbol"
                className="h-24 w-24 rounded-full border-2 border-border/30 shadow-lg"
              />
            </div>

            {/* Main Title */}
            <div className="space-y-6">
              <h1 className="font-zen-serif text-4xl md:text-6xl lg:text-7xl tracking-wide text-foreground leading-relaxed">
                Chân Kinh Online
              </h1>
              <p className="font-zen-serif text-lg md:text-xl tracking-widest text-muted-foreground uppercase">
                Thư viện kinh điển số
              </p>
            </div>

            {/* Quote */}
            <blockquote className="max-w-2xl mx-auto">
              <p className="font-zen-serif text-xl md:text-2xl text-foreground leading-relaxed italic">
                "Học để hiểu, hiểu để hành, hành để chứng"
              </p>
            </blockquote>

            {/* Subtle CTA */}
            <div className="pt-8">
              <Link href="/kinh-cac">
                <Button
                  variant="outline"
                  size="lg"
                  className="font-zen-serif tracking-wider border-border/50 hover:bg-muted/30 hover:text-primary transition-all duration-300"
                >
                  Bắt đầu hành trình
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Reflection Section */}
        <ReflectionSection
          quote="Giáo dục không phải là việc lấp đầy một cái thùng, mà là việc thắp sáng một ngọn lửa."
          author="Socrates"
          subtitle="Tầm nhìn"
          title="Học để trở thành người khác tốt hơn"
          content="Chân Kinh Online là một không gian tĩnh lặng dành cho những người đang tìm kiếm tri thức sâu sắc. Chúng tôi không dạy bạn cách thành công nhanh chóng, mà hướng dẫn bạn đi sâu vào bản chất của mọi sự việc. Ở đây, tri thức được chờ đợi, không bị thúc đẩy."
          variant="muted"
        />

        <ZenDivider variant="gradient" spacing="large" />

        {/* Featured Courses */}
        <section className="py-16 md:py-24 px-4 md:px-8">
          <div className="container mx-auto max-w-6xl space-y-12">
            {/* Section Header */}
            <div className="text-center space-y-4">
              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                Khám phá
              </p>
              <h2 className="font-zen-serif text-3xl md:text-4xl text-foreground">
                Kinh sách đề xuất
              </h2>
              <p className="font-zen-sans text-base text-muted-foreground max-w-2xl mx-auto">
                Những khóa học được lựa chọn kỹ lưỡng để khởi đầu hành trình tri thức của bạn
              </p>
            </div>

            {/* Course Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredCourses.map((course) => (
                <ScriptureCard key={course.id} {...course} />
              ))}
            </div>

            {/* View All */}
            <div className="text-center pt-8">
              <Link href="/kinh-cac">
                <Button
                  variant="ghost"
                  size="lg"
                  className="font-zen-serif tracking-wider text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-all duration-300"
                >
                  Xem tất cả kinh sách
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Final Reflection */}
        <ReflectionSection
          quote="Con đường dài ngàn dặm bắt đầu từ một bước chân."
          author="Lão Tử"
          content="Mỗi kinh sách ở đây là một bước chân. Không vội vã, không áp lực. Chỉ có bạn và tri thức. Hãy bắt đầu khi bạn sẵn sàng."
          variant="bordered"
          alignment="center"
        />
      </main>

      <ZenFooter />
    </div>
  )
}
