'use client'

import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ZenDivider } from '@/components/zen-divider'
import { ReflectionSection } from '@/components/reflection-section'
import { Card, CardContent } from '@/components/ui/card'

export default function PhilosophyPage() {
  const principles = [
    {
      title: 'Tĩnh Lặng',
      description:
        'Tạo không gian cho suy tư và suy ngẫm. Tri thức đến khi tâm trí an định, không khi bị tiếng ồn hay áp lực chi phối.',
    },
    {
      title: 'Tự Học',
      description:
        'Mỗi người có tốc độ học tập riêng. Không có điểm số, không có so sánh, chỉ có sự tiến bộ cá nhân.',
    },
    {
      title: 'Sự Kiên Nhẫn',
      description:
        'Hiểu biết sâu sắc cần thời gian. Chúng tôi tôn trọng quá trình, không vội vã đến đích.',
    },
    {
      title: 'Trân Trọng',
      description:
        'Mỗi kiến thức, mỗi lời dạy đều quý giá. Học để hiểu, không phải để tích lũy.',
    },
    {
      title: 'Thực Hành',
      description:
        'Tri thức không nằm trong sách vở mà trong hành động. Mỗi bài học kèm theo thực hành.',
    },
    {
      title: 'Cộng Đồng',
      description:
        'Một không gian để chia sẻ và học hỏi lẫn nhau. Không phải để tranh luận, mà để cùng phát triển.',
    },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="min-h-[70vh] flex items-center justify-center px-4 md:px-8 bg-gradient-to-b from-muted/20 to-background">
          <div className="container mx-auto max-w-4xl text-center space-y-12">
            <div className="space-y-6">
              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                Tông Chỉ
              </p>
              <h1 className="font-zen-serif text-4xl md:text-5xl lg:text-6xl text-foreground tracking-wide leading-relaxed">
                Tôn chỉ của Chân Kinh Online
              </h1>
            </div>

            <blockquote className="max-w-2xl mx-auto">
              <p className="font-zen-serif text-xl md:text-2xl text-foreground leading-relaxed italic">
                "Tri thức là ánh sáng soi đường, nhưng không phải là đích đến."
              </p>
            </blockquote>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Introduction */}
        <section className="relative py-16 md:py-24 px-4 md:px-8">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img
              src="/images/temple-mountain.jpg"
              alt="Zen temple on mountain"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-background/90" />
          </div>

          <div className="relative z-10 container mx-auto max-w-4xl space-y-12">
            <ReflectionSection
              quote="Trong sự tĩnh lặng, chúng ta nghe được tiếng lòng mình."
              subtitle="Sứ mệnh"
              title="Tạo không gian cho sự suy tư"
              content="Chân Kinh Online không phải là một nền tảng giáo dục truyền thống. Chúng tôi không hứa hẹn thành công nhanh chóng hay kiến thức áp dụng ngay lập tức. Thay vào đó, chúng tôi cung cấp một không gian tĩnh lặng nơi bạn có thể đến, ngồi xuống, và suy ngẫm những câu hỏi sâu sắc về bản thân và thế giới.

Ở đây, không có điểm số, không có bảng xếp hạng, không có áp lực hoàn thành. Chỉ có bạn và tri thức đang chờ đợi được khám phá theo cách riêng của bạn."
              variant="default"
              alignment="center"
            />
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Principles */}
        <section className="py-16 md:py-24 px-4 md:px-8">
          <div className="container mx-auto max-w-6xl">
            <div className="space-y-16">
              <div className="text-center space-y-4">
                <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                  Nguyên tắc
                </p>
                <h2 className="font-zen-serif text-3xl md:text-4xl text-foreground">
                  Những gì chúng tôi tin
                </h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {principles.map((principle, index) => (
                  <Card key={index} className="border-border/50 bg-card/50 zen-card-hover">
                    <CardContent className="p-6 space-y-4">
                      <h3 className="font-zen-serif text-xl text-foreground">
                        {principle.title}
                      </h3>
                      <p className="font-zen-sans text-base text-muted-foreground leading-relaxed">
                        {principle.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Philosophy */}
        <ReflectionSection
          quote="Học để hiểu, hiểu để hành, hành để chứng."
          subtitle="Triết lý"
          title="Học, Hiểu, Hành, Chứng"
          content={`Con đường học tập ở Chân Kinh Online được chia thành bốn giai đoạn, tương ứng với bốn chữ: Học, Hiểu, Hành, Chứng.

Học: Tiếp nhận kiến thức qua lời dạy, kinh sách, và bài học. Đây là bước đầu tiên, nhưng không phải là cuối cùng.

Hiểu: Phản tư và suy ngẫm về những gì đã học. Đặt câu hỏi, tìm hiểu sâu hơn, không chấp nhận một cách mù quáng.

Hành: Áp dụng kiến thức vào cuộc sống. Tri thức chỉ thực sự có giá trị khi được thực hành.

Chứng: Trải nghiệm sự thật từ chính thực hành của mình. Đây là đích đến, nơi tri thức biến thành sự hiểu biết sâu sắc.

Mỗi giai đoạn đều quan trọng như nhau. Chúng tôi không thúc đẩy bạn đi nhanh, mà khuyến khích bạn đi sâu từng bước.`}
          variant="bordered"
          alignment="center"
        />

        <ZenDivider variant="gradient" spacing="large" />

        {/* Final Message */}
        <ReflectionSection
          quote="Hành trình ngàn dặm bắt đầu từ một bước chân. Bước chân đầu tiên có thể là khóa học này."
          content="Chúng tôi chào đón bạn đến với Chân Kinh Online, bất kể bạn đang ở đâu trong hành trình của mình. Tất cả những gì chúng tôi mong muốn là bạn tìm thấy gì đó ý nghĩa ở đây—một lời, một ý tưởng, hay một khoảnh khắc tĩnh lặng—đó là đủ."
          variant="default"
          alignment="center"
        />
      </main>

      <ZenFooter />
    </div>
  )
}
