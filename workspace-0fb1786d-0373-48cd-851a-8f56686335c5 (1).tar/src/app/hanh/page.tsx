'use client'

import { useState } from 'react'
import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ZenDivider } from '@/components/zen-divider'
import { ReflectionSection } from '@/components/reflection-section'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import Link from 'next/link'

export default function EnrollmentPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    commitment: false,
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Integrate with API
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {!submitted ? (
          <>
            {/* Hero Section */}
            <section className="min-h-[60vh] flex items-center justify-center px-4 md:px-8 bg-gradient-to-b from-muted/20 to-background">
              <div className="container mx-auto max-w-4xl text-center space-y-12">
                <div className="space-y-6">
                  <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                    Hành
                  </p>
                  <h1 className="font-zen-serif text-4xl md:text-5xl lg:text-6xl text-foreground tracking-wide leading-relaxed">
                    Gia nhập hành trình
                  </h1>
                </div>

                <blockquote className="max-w-2xl mx-auto">
                  <p className="font-zen-serif text-xl md:text-2xl text-foreground leading-relaxed italic">
                    "Khi tâm trí sẵn sàng, con đường tự hiện ra."
                  </p>
                </blockquote>
              </div>
            </section>

            <ZenDivider variant="gradient" spacing="large" />

            {/* Enrollment Form */}
            <section className="py-16 md:py-24 px-4 md:px-8">
              <div className="container mx-auto max-w-2xl">
                <div className="space-y-12">
                  <div className="text-center space-y-4">
                    <h2 className="font-zen-serif text-3xl text-foreground">
                      Đăng ký
                    </h2>
                    <p className="font-zen-sans text-base text-muted-foreground">
                      Điền thông tin của bạn để bắt đầu hành trình
                    </p>
                  </div>

                  <Card className="border-border/50 bg-card/50">
                    <CardContent className="p-8 md:p-12">
                      <form onSubmit={handleSubmit} className="space-y-8">
                        {/* Name */}
                        <div className="space-y-3">
                          <Label
                            htmlFor="name"
                            className="font-zen-serif text-sm tracking-wider"
                          >
                            Tên của bạn
                          </Label>
                          <Input
                            id="name"
                            type="text"
                            placeholder="Nhập tên của bạn"
                            value={formData.name}
                            onChange={(e) =>
                              setFormData({ ...formData, name: e.target.value })
                            }
                            required
                            className="font-zen-sans text-base border-border/50 focus:border-primary/50"
                          />
                        </div>

                        {/* Email */}
                        <div className="space-y-3">
                          <Label
                            htmlFor="email"
                            className="font-zen-serif text-sm tracking-wider"
                          >
                            Email
                          </Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="Nhập email của bạn"
                            value={formData.email}
                            onChange={(e) =>
                              setFormData({ ...formData, email: e.target.value })
                            }
                            required
                            className="font-zen-sans text-base border-border/50 focus:border-primary/50"
                          />
                        </div>

                        {/* Commitment */}
                        <div className="space-y-4 pt-4">
                          <div className="flex items-start space-x-3">
                            <Checkbox
                              id="commitment"
                              checked={formData.commitment}
                              onCheckedChange={(checked) =>
                                setFormData({ ...formData, commitment: checked as boolean })
                              }
                              required
                              className="mt-1"
                            />
                            <Label
                              htmlFor="commitment"
                              className="font-zen-sans text-sm text-muted-foreground leading-relaxed cursor-pointer"
                            >
                              Tôi cam kết sẽ học tập một cách nghiêm túc và tôn trọng
                              những gì mình tiếp nhận. Tôi hiểu rằng hành trình này
                              cần thời gian và kiên nhẫn.
                            </Label>
                          </div>
                        </div>

                        {/* Submit */}
                        <div className="pt-4">
                          <Button
                            type="submit"
                            size="lg"
                            className="w-full font-zen-serif tracking-wider bg-primary hover:bg-primary/90 transition-all duration-300"
                            disabled={!formData.commitment}
                          >
                            Gia nhập
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>

                  {/* Reflection */}
                  <div className="text-center space-y-4 pt-8">
                    <p className="font-zen-serif text-sm text-muted-foreground italic">
                      "Không vội vã, không áp lực. Chỉ có bạn và tri thức."
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <ZenDivider variant="gradient" spacing="large" />

            {/* What to Expect */}
            <section className="py-16 md:py-24 px-4 md:px-8">
              <div className="container mx-auto max-w-4xl">
                <div className="space-y-12">
                  <div className="text-center space-y-4">
                    <h2 className="font-zen-serif text-3xl text-foreground">
                      Điều sẽ diễn ra
                    </h2>
                  </div>

                  <div className="space-y-6">
                    <Card className="border-border/50 bg-card/50">
                      <CardContent className="p-6 space-y-2">
                        <h3 className="font-zen-serif text-lg text-foreground">
                          Chào mừng
                        </h3>
                        <p className="font-zen-sans text-sm text-muted-foreground leading-relaxed">
                          Bạn sẽ nhận được một email chào mừng với hướng dẫn
                          bắt đầu.
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-border/50 bg-card/50">
                      <CardContent className="p-6 space-y-2">
                        <h3 className="font-zen-serif text-lg text-foreground">
                          Tiếp cận
                        </h3>
                        <p className="font-zen-sans text-sm text-muted-foreground leading-relaxed">
                          Bạn sẽ có quyền truy cập vào tất cả các khóa học đã chọn.
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-border/50 bg-card/50">
                      <CardContent className="p-6 space-y-2">
                        <h3 className="font-zen-serif text-lg text-foreground">
                          Học tập
                        </h3>
                        <p className="font-zen-sans text-sm text-muted-foreground leading-relaxed">
                          Bạn có thể học theo tốc độ của riêng mình, không có áp lực.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </section>
          </>
        ) : (
          /* Success State */
          <>
            <section className="min-h-[80vh] flex items-center justify-center px-4 md:px-8">
              <div className="container mx-auto max-w-2xl text-center space-y-12">
                <div className="space-y-6">
                  <div className="flex justify-center">
                    <div className="h-20 w-20 flex items-center justify-center rounded-full bg-primary/10 border border-primary/30">
                      <svg
                        className="h-10 w-10 text-primary"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                      Chào mừng
                    </p>
                    <h1 className="font-zen-serif text-3xl md:text-4xl lg:text-5xl text-foreground tracking-wide">
                      Bạn đã gia nhập
                    </h1>
                  </div>

                  <p className="font-zen-sans text-base text-muted-foreground max-w-md mx-auto leading-relaxed">
                    Cảm ơn bạn đã tham gia cùng chúng tôi. Một email chào mừng đã
                    được gửi đến {formData.email}.
                  </p>

                  <blockquote className="pt-8">
                    <p className="font-zen-serif text-xl text-foreground leading-relaxed italic">
                      "Con đường dài ngàn dặm bắt đầu từ một bước chân. Bạn đã
                      đặt bước chân đầu tiên."
                    </p>
                  </blockquote>
                </div>

                <div className="space-y-4">
                  <Link href="/kinh-cac">
                    <Button
                      size="lg"
                      className="font-zen-serif tracking-wider bg-primary hover:bg-primary/90 transition-all duration-300"
                    >
                      Bắt đầu học
                    </Button>
                  </Link>
                  <div className="pt-4">
                    <Link
                      href="/"
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      Về trang chủ
                    </Link>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}
      </main>

      <ZenFooter />
    </div>
  )
}
