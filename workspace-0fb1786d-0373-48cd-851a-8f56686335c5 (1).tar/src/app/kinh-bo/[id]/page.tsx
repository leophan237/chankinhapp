'use client'

import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ZenDivider } from '@/components/zen-divider'
import { ReflectionSection } from '@/components/reflection-section'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { CheckCircle, Clock, Users, BookOpen } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'

// Sample data - will be replaced with API data
const courseData = {
  id: '1',
  title: 'Đạo Đức Kinh',
  subtitle: 'Kinh điển cơ bản',
  description:
    'Khởi hành từ những lời dạy cơ bản về đạo đức và lối sống. Một hành trình khám phá bản chất của tâm trí và hành vi con người.',
  category: 'Kinh điển',
  duration: '8 tuần',
  students: 128,
  lessons: 24,
  level: 'Nhập môn',
  quote: 'Học để hiểu, hiểu để hành, hành để chứng',
  longDescription: `Đạo Đức Kinh là nền tảng của mọi tri thức. Trong khóa học này, chúng ta sẽ cùng nhau khám phá những nguyên tắc cơ bản về đạo đức và lối sống, không phải dưới góc độ quy tắc hay kỷ luật, mà như một con đường dẫn đến sự hiểu biết sâu sắc về bản thân.

Mỗi bài học được thiết kế để khơi gợi sự suy tư và thực hành. Không có bài kiểm tra, không có áp lực hoàn thành, chỉ có bạn và tri thức đang chờ đợi được khám phá.

Khóa học bao gồm 24 bài học, mỗi bài có thể hoàn thành trong 2-3 ngày thực hành nhẹ nhàng. Bạn có thể đi theo tốc độ của riêng mình, không cần vội vã.`,
  curriculum: [
    {
      title: 'Phần 1: Nhập môn',
      lessons: [
        { title: 'Đạo là gì?', duration: '15 phút' },
        { title: 'Bản chất của tâm', duration: '20 phút' },
        { title: 'Ý nghĩa của đạo đức', duration: '18 phút' },
      ],
    },
    {
      title: 'Phần 2: Thực hành',
      lessons: [
        { title: 'Thân', duration: '25 phút' },
        { title: 'Khẩu', duration: '22 phút' },
        { title: 'Ý', duration: '30 phút' },
        { title: 'Sống tỉnh thức', duration: '28 phút' },
      ],
    },
    {
      title: 'Phần 3: Củng cố',
      lessons: [
        { title: 'Gặp khó khăn', duration: '20 phút' },
        { title: 'Kiên trì', duration: '25 phút' },
        { title: 'Tiếp tục hành trình', duration: '30 phút' },
      ],
    },
  ],
  prerequisites: ['Không có yêu cầu trước'],
  outcomes: [
    'Hiểu rõ hơn về bản chất của đạo đức',
    'Phát triển sự tỉnh thức trong cuộc sống hàng ngày',
    'Biết cách thực hành những lời dạy cơ bản',
  ],
}

export default function CourseDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const [enrolled, setEnrolled] = useState(false)

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-24 px-4 md:px-8 bg-gradient-to-b from-muted/20 to-background">
          <div className="container mx-auto max-w-4xl">
            <div className="space-y-8">
              {/* Breadcrumb */}
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Link href="/kinh-cac" className="hover:text-foreground transition-colors">
                  Kinh Các
                </Link>
                <span>/</span>
                <span className="text-foreground">{courseData.title}</span>
              </div>

              {/* Header */}
              <div className="space-y-4">
                {courseData.category && (
                  <Badge
                    variant="secondary"
                    className="font-zen-serif text-xs tracking-wider"
                  >
                    {courseData.category}
                  </Badge>
                )}
                {courseData.subtitle && (
                  <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                    {courseData.subtitle}
                  </p>
                )}
                <h1 className="font-zen-serif text-4xl md:text-5xl lg:text-6xl text-foreground tracking-wide">
                  {courseData.title}
                </h1>
                <p className="font-zen-sans text-base text-muted-foreground leading-relaxed">
                  {courseData.description}
                </p>
              </div>

              {/* Quote */}
              {courseData.quote && (
                <blockquote className="border-l-4 border-primary pl-6 py-2">
                  <p className="font-zen-serif text-lg md:text-xl text-foreground italic">
                    {courseData.quote}
                  </p>
                </blockquote>
              )}

              {/* Metadata */}
              <div className="flex flex-wrap gap-6 pt-4">
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Clock className="h-5 w-5" />
                  <span className="font-zen-sans text-sm">{courseData.duration}</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <Users className="h-5 w-5" />
                  <span className="font-zen-sans text-sm">{courseData.students} học viên</span>
                </div>
                <div className="flex items-center space-x-2 text-muted-foreground">
                  <BookOpen className="h-5 w-5" />
                  <span className="font-zen-sans text-sm">{courseData.lessons} bài học</span>
                </div>
              </div>

              {/* CTA */}
              <div className="pt-4">
                {!enrolled ? (
                  <Link href="/hanh">
                    <Button
                      size="lg"
                      className="font-zen-serif tracking-wider bg-primary hover:bg-primary/90 transition-all duration-300"
                    >
                      Gia nhập khóa học
                    </Button>
                  </Link>
                ) : (
                  <Link href="/hoc-luyen/1">
                    <Button
                      size="lg"
                      variant="outline"
                      className="font-zen-serif tracking-wider border-border/50 hover:bg-muted/30 transition-all duration-300"
                    >
                      Tiếp tục học
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* About Section */}
        <section className="py-16 md:py-24 px-4 md:px-8">
          <div className="container mx-auto max-w-4xl">
            <div className="prose prose-lg max-w-none">
              <div className="space-y-8">
                <div className="text-center space-y-4">
                  <h2 className="font-zen-serif text-3xl md:text-4xl text-foreground">
                    Về khóa học này
                  </h2>
                </div>

                <div className="font-zen-sans text-base text-muted-foreground leading-relaxed whitespace-pre-line">
                  {courseData.longDescription}
                </div>
              </div>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Curriculum Section */}
        <section className="py-16 md:py-24 px-4 md:px-8">
          <div className="container mx-auto max-w-4xl">
            <div className="space-y-12">
              <div className="text-center space-y-4">
                <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                  Nội dung
                </p>
                <h2 className="font-zen-serif text-3xl md:text-4xl text-foreground">
                  Chương trình học
                </h2>
              </div>

              <div className="space-y-8">
                {courseData.curriculum.map((section, index) => (
                  <Card key={index} className="border-border/50 bg-card/50">
                    <CardContent className="p-6 md:p-8">
                      <h3 className="font-zen-serif text-xl text-foreground mb-6">
                        {section.title}
                      </h3>
                      <div className="space-y-4">
                        {section.lessons.map((lesson, lessonIndex) => (
                          <div key={lessonIndex}>
                            <div className="flex items-center space-x-4">
                              <CheckCircle className="h-5 w-5 text-muted-foreground/30" />
                              <div className="flex-1">
                                <p className="font-zen-sans text-base text-foreground">
                                  {lesson.title}
                                </p>
                              </div>
                              <div className="flex items-center space-x-2 text-muted-foreground">
                                <Clock className="h-4 w-4" />
                                <span className="font-zen-sans text-sm">
                                  {lesson.duration}
                                </span>
                              </div>
                            </div>
                            {lessonIndex < section.lessons.length - 1 && (
                              <Separator className="mt-4" />
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Requirements & Outcomes */}
        <section className="py-16 md:py-24 px-4 md:px-8">
          <div className="container mx-auto max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              {/* Requirements */}
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-zen-serif text-2xl text-foreground">
                    Yêu cầu
                  </h3>
                </div>
                <ul className="space-y-3">
                  {courseData.prerequisites.map((item, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary mt-2" />
                      <span className="font-zen-sans text-base text-muted-foreground">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Outcomes */}
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-zen-serif text-2xl text-foreground">
                    Kết quả học tập
                  </h3>
                </div>
                <ul className="space-y-3">
                  {courseData.outcomes.map((item, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="font-zen-sans text-base text-muted-foreground">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Final CTA */}
        <ReflectionSection
          quote="Con đường dài ngàn dặm bắt đầu từ một bước chân."
          author="Lão Tử"
          content="Bạn đã sẵn sàng cho hành trình này? Gia nhập khóa học và bắt đầu bước chân đầu tiên."
          variant="muted"
          alignment="center"
        />
      </main>

      <ZenFooter />
    </div>
  )
}
