'use client'

import { useState } from 'react'
import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ZenDivider } from '@/components/zen-divider'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { MessageSquare, Heart, Clock } from 'lucide-react'

// Sample discussions
const discussions = [
  {
    id: 1,
    title: 'Làm thế nào để duy trì sự tỉnh thức trong công việc bận rộn?',
    author: 'Thiền sinh Minh',
    initials: 'TM',
    content:
      'Mình đã thử nhiều cách nhưng vẫn thường xuyên quên mất sự tỉnh thức khi công việc quá tải. Có ai có kinh nghiệm chia sẻ không?',
    category: 'Thực hành',
    replies: 12,
    likes: 24,
    time: '2 giờ trước',
  },
  {
    id: 2,
    title: 'Hành trình với Đạo Đức Kinh',
    author: 'Người học đường',
    initials: 'NHD',
    content:
      'Đang học bài thứ 3 và cảm thấy thay đổi dần dần. Có ai đang học khóa này không? Cùng chia sẻ kinh nghiệm nhé.',
    category: 'Kinh điển',
    replies: 8,
    likes: 19,
    time: '5 giờ trước',
  },
  {
    id: 3,
    title: 'Sự khác biệt giữa hiểu và chứng',
    author: 'Tâm Bất Biến',
    initials: 'TB',
    content:
      'Mình đang suy ngẫm về sự khác biệt giữa hiểu bằng lý trí và thực chứng từ kinh nghiệm. Rất mong nhận được góc nhìn từ mọi người.',
    category: 'Triết lý',
    replies: 15,
    likes: 32,
    time: '1 ngày trước',
  },
  {
    id: 4,
    title: 'Lịch sử Chân Kinh Online',
    author: 'Sinh viên',
    initials: 'SV',
    content:
      'Mình mới gia nhập và rất tò mò về nguồn gốc và lịch sử phát triển của nền tảng này. Có ai biết không ạ?',
    category: 'Tổng quan',
    replies: 6,
    likes: 14,
    time: '2 ngày trước',
  },
  {
    id: 5,
    title: 'Gặp khó khăn khi thực hành chánh niệm',
    author: 'Trên con đường',
    initials: 'T',
    content:
      'Đôi khi mình cảm thấy thực hành càng khó hơn thay vì dễ hơn. Đây có phải là dấu hiệu bình thường không?',
    category: 'Thực hành',
    replies: 20,
    likes: 28,
    time: '3 ngày trước',
  },
]

const categories = ['Tất cả', 'Thực hành', 'Kinh điển', 'Triết lý', 'Tổng quan']

export default function CommunityPage() {
  const [selectedCategory, setSelectedCategory] = useState('Tất cả')
  const [showNewDiscussion, setShowNewDiscussion] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const filteredDiscussions = discussions.filter((discussion) => {
    const matchesCategory =
      selectedCategory === 'Tất cả' || discussion.category === selectedCategory
    const matchesSearch =
      discussion.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      discussion.content.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-16 md:py-24 px-4 md:px-8 overflow-hidden">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img
              src="/images/community.jpg"
              alt="Community meditation"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/85 via-background/90 to-background" />
          </div>

          <div className="relative z-10 container mx-auto max-w-4xl text-center space-y-12">
            <div className="space-y-6">
              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                Đạo Tràng
              </p>
              <h1 className="font-zen-serif text-4xl md:text-5xl lg:text-6xl text-foreground tracking-wide leading-relaxed">
                Không gian chia sẻ
              </h1>
            </div>

            <blockquote className="max-w-2xl mx-auto">
              <p className="font-zen-serif text-xl md:text-2xl text-foreground leading-relaxed italic">
                "Khi chia sẻ, tri thức sinh sôi. Khi lắng nghe, tâm trí mở rộng."
              </p>
            </blockquote>

            <p className="font-zen-sans text-base text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Đạo Tràng là nơi chúng ta cùng nhau suy ngẫm, chia sẻ và học hỏi.
              Không phải để tranh luận đúng sai, mà để cùng phát triển.
            </p>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Search and Filter */}
        <section className="py-8 md:py-12 px-4 md:px-8">
          <div className="container mx-auto max-w-6xl">
            <div className="space-y-8">
              {/* Search */}
              <div className="max-w-2xl mx-auto">
                <div className="relative">
                  <MessageSquare className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Tìm kiếm cuộc thảo luận..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-12 font-zen-sans text-base border-border/50 focus:border-primary/50"
                  />
                </div>
              </div>

              {/* Category Filter */}
              <div className="flex flex-wrap gap-3 justify-center">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className={`font-zen-serif text-xs tracking-wider ${
                      selectedCategory === category
                        ? 'bg-primary text-primary-foreground'
                        : 'border-border/50 hover:bg-muted/30'
                    }`}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              {/* New Discussion Button */}
              <div className="text-center">
                <Button
                  onClick={() => setShowNewDiscussion(!showNewDiscussion)}
                  variant="outline"
                  size="lg"
                  className="font-zen-serif tracking-wider border-border/50 hover:bg-muted/30"
                >
                  {showNewDiscussion ? 'Đóng' : 'Bắt đầu cuộc thảo luận'}
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* New Discussion Form */}
        {showNewDiscussion && (
          <>
            <ZenDivider variant="gradient" spacing="medium" />
            <section className="py-8 md:py-12 px-4 md:px-8">
              <div className="container mx-auto max-w-3xl">
                <Card className="border-border/50 bg-card/50">
                  <CardContent className="p-6 md:p-8 space-y-6">
                    <div className="space-y-2">
                      <h3 className="font-zen-serif text-xl text-foreground">
                        Bắt đầu một cuộc thảo luận mới
                      </h3>
                      <p className="font-zen-sans text-sm text-muted-foreground">
                        Chia sẻ suy nghĩ của bạn một cách chân thành
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="font-zen-serif text-sm tracking-wider text-foreground">
                          Tiêu đề
                        </label>
                        <Input
                          type="text"
                          placeholder="Nhập tiêu đề..."
                          className="font-zen-sans text-base border-border/50 focus:border-primary/50"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="font-zen-serif text-sm tracking-wider text-foreground">
                          Danh mục
                        </label>
                        <select className="w-full px-4 py-3 font-zen-sans text-base border border-border/50 rounded-md focus:border-primary/50 focus:outline-none bg-background">
                          <option>Thực hành</option>
                          <option>Kinh điển</option>
                          <option>Triết lý</option>
                          <option>Tổng quan</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="font-zen-serif text-sm tracking-wider text-foreground">
                          Nội dung
                        </label>
                        <Textarea
                          placeholder="Nhập nội dung thảo luận..."
                          rows={6}
                          className="font-zen-sans text-base border-border/50 focus:border-primary/50 resize-none"
                        />
                      </div>

                      <div className="flex justify-end space-x-4 pt-4">
                        <Button
                          variant="ghost"
                          onClick={() => setShowNewDiscussion(false)}
                          className="font-zen-serif text-muted-foreground hover:text-foreground"
                        >
                          Hủy
                        </Button>
                        <Button className="font-zen-serif tracking-wider bg-primary hover:bg-primary/90">
                          Đăng bài
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </section>
            <ZenDivider variant="gradient" spacing="medium" />
          </>
        )}

        {/* Discussions List */}
        <section className="py-8 md:py-16 px-4 md:px-8">
          <div className="container mx-auto max-w-4xl">
            <div className="space-y-6">
              {filteredDiscussions.length > 0 ? (
                filteredDiscussions.map((discussion) => (
                  <Card
                    key={discussion.id}
                    className="border-border/50 bg-card/50 zen-card-hover cursor-pointer"
                  >
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {/* Header */}
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback className="bg-muted/50 font-zen-serif text-sm">
                                {discussion.initials}
                              </AvatarFallback>
                            </Avatar>
                            <div className="space-y-1">
                              <p className="font-zen-sans text-sm text-foreground">
                                {discussion.author}
                              </p>
                              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                <span>{discussion.time}</span>
                              </div>
                            </div>
                          </div>
                          <Badge
                            variant="secondary"
                            className="font-zen-serif text-xs tracking-wider bg-muted/50"
                          >
                            {discussion.category}
                          </Badge>
                        </div>

                        {/* Content */}
                        <div className="space-y-3">
                          <h3 className="font-zen-serif text-lg text-foreground leading-relaxed">
                            {discussion.title}
                          </h3>
                          <p className="font-zen-sans text-sm text-muted-foreground line-clamp-2 leading-relaxed">
                            {discussion.content}
                          </p>
                        </div>

                        <Separator className="bg-border/30" />

                        {/* Footer */}
                        <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-2">
                            <MessageSquare className="h-4 w-4" />
                            <span className="font-zen-sans">{discussion.replies}</span>
                            <span className="font-zen-sans">trả lời</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Heart className="h-4 w-4" />
                            <span className="font-zen-sans">{discussion.likes}</span>
                            <span className="font-zen-sans">thích</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-16 space-y-4">
                  <p className="font-zen-serif text-xl text-muted-foreground">
                    Không tìm thấy cuộc thảo luận nào
                  </p>
                  <p className="font-zen-sans text-sm text-muted-foreground">
                    Thử thay đổi từ khóa hoặc danh mục tìm kiếm
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      <ZenFooter />
    </div>
  )
}
