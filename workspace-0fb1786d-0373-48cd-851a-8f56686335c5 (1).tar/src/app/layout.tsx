import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const playfairDisplay = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin", "vietnamese"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Chân Kinh Online - Digital Scripture Library",
  description: "A contemplative e-learning platform for deep learning and reflection. Explore courses with calm, Zen-inspired aesthetics.",
  keywords: ["e-learning", "zen", "contemplative", "learning", "courses"],
  authors: [{ name: "Chân Kinh Online" }],
  openGraph: {
    title: "Chân Kinh Online - Digital Scripture Library",
    description: "A contemplative e-learning platform for deep learning and reflection",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${playfairDisplay.variable} antialiased bg-background text-foreground font-zen-sans zen-text`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
