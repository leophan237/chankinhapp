'use client'

import { useState } from 'react'
import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ScriptureCard } from '@/components/scripture-card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ZenDivider } from '@/components/zen-divider'
import { Search, Filter } from 'lucide-react'

// Sample data - will be replaced with API data
const allCourses = [
  {
    id: '1',
    title: 'Đạo Đức Kinh',
    subtitle: 'Kinh điển cơ bản',
    description:
      'Khởi hành từ những lời dạy cơ bản về đạo đức và lối sống. Một hành trình khám phá bản chất của tâm trí và hành vi con người.',
    category: 'Kinh điển',
    duration: '8 tuần',
    students: 128,
    image: '/images/scripture-1.jpg',
  },
  {
    id: '2',
    title: 'Thiền Định Nhập Môn',
    subtitle: 'Thực hành tâm linh',
    description:
      'Học cách an trú trong hiện tại và phát triển sự tỉnh thức. Những kỹ thuật thiền định cơ bản cho người mới bắt đầu.',
    category: 'Thực hành',
    duration: '6 tuần',
    students: 96,
    image: '/images/meditation.jpg',
  },
  {
    id: '3',
    title: 'Bát Chánh Đạo',
    subtitle: 'Hành trình giác ngộ',
    description:
      'Mười sáu bài học về con đường Trung Đạo. Một hệ thống hoàn chỉnh để hiểu rõ bản chất của khổ đau và sự giải thoát.',
    category: 'Kinh điển',
    duration: '16 tuần',
    students: 243,
    image: '/images/eightfold-path.jpg',
  },
  {
    id: '4',
    title: 'Kinh Dược Sư',
    subtitle: 'Hành trình chữa lành',
    description:
      'Khám phá sức mạnh chữa lành của tâm thức qua những lời dạy của Kinh Dược Sư Lưu Li Quang Vương.',
    category: 'Kinh điển',
    duration: '12 tuần',
    students: 187,
    image: '/images/lotus.jpg',
  },
  {
    id: '5',
    title: 'Chánh Niệm Trong Cuộc Sống',
    subtitle: 'Thực hành hàng ngày',
    description:
      'Áp dụng chánh niệm vào các hoạt động thường ngày: ăn uống, đi lại, làm việc. Tìm kiếm sự bình an trong từng khoảnh khắc.',
    category: 'Thực hành',
    duration: '4 tuần',
    students: 312,
    image: '/images/mindfulness.jpg',
  },
  {
    id: '6',
    title: 'Kinh Kim Cương',
    subtitle: 'Bản chất của sự thật',
    description:
      'Một trong những kinh văn quan trọng nhất của Đại thừa. Giải mã bản chất không và sự thật tuyệt đối.',
    category: 'Kinh điển',
    duration: '20 tuần',
    students: 89,
    image: '/images/temple-mountain.jpg',
  },
  {
    id: '7',
    title: 'Biết Trả Lời',
    subtitle: 'Giao tiếp tỉnh thức',
    description:
      'Học cách lắng nghe sâu và phản hồi với từ ngữ yêu thương. Kỹ năng giao tiếp trong các mối quan hệ.',
    category: 'Thực hành',
    duration: '5 tuần',
    students: 156,
    image: '/images/tea-ceremony.jpg',
  },
  {
    id: '8',
    title: 'Kinh Hoa Nghiêm',
    subtitle: 'Vũ trụ tâm thức',
    description:
      'Mở rộng hiểu biết về thế giới qua lăng kính của Kinh Hoa Nghiêm. Mối quan hệ tương giao giữa mọi sự vật.',
    category: 'Kinh điển',
    duration: '24 tuần',
    students: 64,
    image: '/images/scripture-1.jpg',
  },
  {
    id: '9',
    title: 'Nuôi Dưỡng Từ Bi',
    subtitle: 'Tâm từ bi',
    description:
      'Trồng mầm từ bi trong tâm thức. Những thực hành đơn giản để nuôi dưỡng tình yêu thương vô điều kiện.',
    category: 'Thực hành',
    duration: '6 tuần',
    students: 203,
    image: '/images/lotus.jpg',
  },
]

const categories = ['Tất cả', 'Kinh điển', 'Thực hành', 'Kinh sách', 'Bài giảng']

export default function CoursesLibraryPage() {
  const [selectedCategory, setSelectedCategory] = useState('Tất cả')
  const [searchQuery, setSearchQuery] = useState('')

  const filteredCourses = allCourses.filter((course) => {
    const matchesCategory =
      selectedCategory === 'Tất cả' || course.category === selectedCategory
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {/* Header Section */}
        <section className="py-16 md:py-24 px-4 md:px-8 bg-gradient-to-b from-muted/20 to-background">
          <div className="container mx-auto max-w-4xl text-center space-y-8">
            <div className="space-y-4">
              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                Thư viện
              </p>
              <h1 className="font-zen-serif text-4xl md:text-5xl text-foreground">
                Kinh Các
              </h1>
              <p className="font-zen-sans text-base text-muted-foreground max-w-2xl mx-auto">
                Khám phá bộ sưu tập kinh sách và khóa học được chắt lọc. Chọn con đường của bạn và bắt đầu hành trình.
              </p>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="large" />

        {/* Search and Filter Section */}
        <section className="py-8 md:py-12 px-4 md:px-8">
          <div className="container mx-auto max-w-6xl">
            <div className="space-y-8">
              {/* Search */}
              <div className="max-w-2xl mx-auto">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Tìm kiếm kinh sách..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-12 font-zen-sans text-base border-border/50 focus:border-primary/50"
                  />
                </div>
              </div>

              {/* Category Filter */}
              <div className="flex flex-wrap gap-3 justify-center">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className={`font-zen-serif text-xs tracking-wider ${
                      selectedCategory === category
                        ? 'bg-primary text-primary-foreground'
                        : 'border-border/50 hover:bg-muted/30'
                    }`}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              {/* Results Count */}
              <div className="text-center">
                <p className="font-zen-sans text-sm text-muted-foreground">
                  Tìm thấy {filteredCourses.length} kinh sách
                </p>
              </div>
            </div>
          </div>
        </section>

        <ZenDivider variant="gradient" spacing="medium" />

        {/* Courses Grid */}
        <section className="py-8 md:py-16 px-4 md:px-8">
          <div className="container mx-auto max-w-7xl">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredCourses.map((course) => (
                <ScriptureCard key={course.id} {...course} />
              ))}
            </div>

            {/* Empty State */}
            {filteredCourses.length === 0 && (
              <div className="text-center py-16 space-y-4">
                <p className="font-zen-serif text-xl text-muted-foreground">
                  Không tìm thấy kinh sách nào
                </p>
                <p className="font-zen-sans text-sm text-muted-foreground">
                  Thử thay đổi từ khóa hoặc danh mục tìm kiếm
                </p>
              </div>
            )}
          </div>
        </section>
      </main>

      <ZenFooter />
    </div>
  )
}
