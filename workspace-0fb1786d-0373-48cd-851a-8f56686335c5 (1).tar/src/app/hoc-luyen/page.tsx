'use client'

import { useState } from 'react'
import { ZenHeader } from '@/components/zen-header'
import { ZenFooter } from '@/components/zen-footer'
import { ZenDivider } from '@/components/zen-divider'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { CheckCircle2, Circle, ChevronRight, ChevronLeft, Book } from 'lucide-react'
import Link from 'next/link'

// Sample course data
const courseData = {
  id: '1',
  title: 'Đạo Đức Kinh',
  subtitle: 'Kinh điển cơ bản',
  description:
    'Khởi hành từ những lời dạy cơ bản về đạo đức và lối sống. Một hành trình khám phá bản chất của tâm trí và hành vi con người.',
}

const lessons = [
  {
    id: 1,
    section: 'Phần 1: Nhập môn',
    title: 'Đạo là gì?',
    duration: '15 phút',
    completed: true,
  },
  {
    id: 2,
    section: 'Phần 1: Nhập môn',
    title: 'Bản chất của tâm',
    duration: '20 phút',
    completed: true,
  },
  {
    id: 3,
    section: 'Phần 1: Nhập môn',
    title: 'Ý nghĩa của đạo đức',
    duration: '18 phút',
    completed: false,
    current: true,
  },
  {
    id: 4,
    section: 'Phần 2: Thực hành',
    title: 'Thân',
    duration: '25 phút',
    completed: false,
  },
  {
    id: 5,
    section: 'Phần 2: Thực hành',
    title: 'Khẩu',
    duration: '22 phút',
    completed: false,
  },
  {
    id: 6,
    section: 'Phần 2: Thực hành',
    title: 'Ý',
    duration: '30 phút',
    completed: false,
  },
  {
    id: 7,
    section: 'Phần 2: Thực hành',
    title: 'Sống tỉnh thức',
    duration: '28 phút',
    completed: false,
  },
  {
    id: 8,
    section: 'Phần 3: Củng cố',
    title: 'Gặp khó khăn',
    duration: '20 phút',
    completed: false,
  },
  {
    id: 9,
    section: 'Phần 3: Củng cố',
    title: 'Kiên trì',
    duration: '25 phút',
    completed: false,
  },
  {
    id: 10,
    section: 'Phần 3: Củng cố',
    title: 'Tiếp tục hành trình',
    duration: '30 phút',
    completed: false,
  },
]

const currentLessonContent = {
  title: 'Ý nghĩa của đạo đức',
  subtitle: 'Bài 3 - Phần 1: Nhập môn',
  content: `Đạo đức không phải là một tập hợp các quy tắc hay kỷ luật cứng nhắc. Nó không phải là một danh sách những việc "nên" và "không nên" làm. Thay vào đó, đạo đức là sự hiểu biết sâu sắc về bản chất của sự vật và mối quan hệ giữa chúng.

Khi chúng ta hiểu đạo đức theo cách này, nó trở thành một hướng dẫn tự nhiên cho hành động của mình, chứ không phải là một áp lực từ bên ngoài.

Đạo đức bắt đầu từ sự quan sát. Quan sát tâm trí, quan sát hành động, quan sát ý định. Qua sự quan sát này, chúng ta bắt đầu thấy rõ mối liên hệ giữa suy nghĩ, lời nói và hành động.

Trong bài học này, chúng ta sẽ cùng nhau khám phá ba khía cạnh chính của đạo đức:

1. Sự tỉnh thức trong mọi hành động
2. Ý định đằng sau mỗi hành động
3. Hậu quả của hành động đối với bản thân và người khác

Hãy dành một chút thời gian để suy ngẫm về từng khía cạnh này trước khi tiếp tục.`,
  reflection: `Sau khi đọc những lời này, hãy ngồi yên trong vài phút và tự hỏi:

Tôi có thực sự hiểu ý nghĩa của hành động của mình không?
Hành động của tôi bắt nguồn từ đâu?
Tôi có nhận thức về hậu quả của hành động của mình không?

Không cần trả lời ngay. Chỉ cần đặt câu hỏi và để câu hỏi ở đó. Sự hiểu biết sẽ đến khi thời điểm chín muồi.`,
}

export default function LearningSpacePage() {
  const [currentLessonId, setCurrentLessonId] = useState(3)
  const [showReflection, setShowReflection] = useState(false)

  const currentLesson = lessons.find((l) => l.id === currentLessonId)
  const completedLessons = lessons.filter((l) => l.completed).length
  const progress = Math.round((completedLessons / lessons.length) * 100)

  const handleNext = () => {
    const nextLesson = lessons.find((l) => l.id === currentLessonId + 1)
    if (nextLesson) {
      setCurrentLessonId(nextLesson.id)
      setShowReflection(false)
    }
  }

  const handlePrevious = () => {
    const previousLesson = lessons.find((l) => l.id === currentLessonId - 1)
    if (previousLesson) {
      setCurrentLessonId(previousLesson.id)
      setShowReflection(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <ZenHeader />

      <main className="flex-1">
        {/* Header */}
        <section className="relative py-6 md:py-8 px-4 md:px-8 border-b border-border/50 overflow-hidden">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img
              src="/images/mindfulness.jpg"
              alt="Mindfulness practice"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-background/95" />
          </div>

          <div className="relative z-10 container mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              {/* Course Info */}
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Link href="/kinh-cac" className="hover:text-foreground transition-colors">
                    Kinh Các
                  </Link>
                  <span>/</span>
                  <span>{courseData.title}</span>
                </div>
                <h1 className="font-zen-serif text-2xl md:text-3xl text-foreground">
                  {courseData.title}
                </h1>
              </div>

              {/* Subtle Progress */}
              <div className="flex items-center space-x-4">
                <div className="text-sm text-muted-foreground font-zen-sans">
                  {completedLessons} / {lessons.length} bài học
                </div>
                <div className="w-32 h-1.5 bg-muted/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary/60 rounded-full transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Content Area */}
        <div className="flex-1">
          <div className="container mx-auto px-4 md:px-8 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Sidebar - Lesson List */}
              <div className="lg:col-span-1">
                <Card className="border-border/50 bg-card/50 sticky top-8">
                  <CardContent className="p-4">
                    <ScrollArea className="h-[calc(100vh-12rem)]">
                      <div className="space-y-4">
                        {lessons.map((lesson, index) => (
                          <div key={lesson.id}>
                            {index === 0 && (
                              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground mb-2">
                                {lesson.section}
                              </p>
                            )}
                            {lessons[index - 1]?.section !== lesson.section && (
                              <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground mb-2 mt-4">
                                {lesson.section}
                              </p>
                            )}
                            <button
                              onClick={() => {
                                setCurrentLessonId(lesson.id)
                                setShowReflection(false)
                              }}
                              className={`w-full text-left p-3 rounded-lg transition-all duration-200 ${
                                currentLessonId === lesson.id
                                  ? 'bg-primary/10 border border-primary/20'
                                  : 'hover:bg-muted/20 border border-transparent'
                              }`}
                            >
                              <div className="flex items-start space-x-3">
                                {lesson.completed ? (
                                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                                ) : (
                                  <Circle className="h-4 w-4 text-muted-foreground/30 mt-0.5 flex-shrink-0" />
                                )}
                                <div className="flex-1 space-y-1">
                                  <p
                                    className={`font-zen-sans text-sm leading-relaxed ${
                                      currentLessonId === lesson.id
                                        ? 'text-foreground'
                                        : 'text-muted-foreground'
                                    }`}
                                  >
                                    {lesson.title}
                                  </p>
                                  <p className="font-zen-sans text-xs text-muted-foreground">
                                    {lesson.duration}
                                  </p>
                                </div>
                              </div>
                            </button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>

              {/* Main Content */}
              <div className="lg:col-span-3">
                <Card className="border-border/50 bg-card/50">
                  <CardContent className="p-6 md:p-8 space-y-8">
                    {/* Lesson Header */}
                    <div className="space-y-4">
                      <p className="font-zen-serif text-xs tracking-widest uppercase text-muted-foreground">
                        {currentLessonContent.subtitle}
                      </p>
                      <h2 className="font-zen-serif text-2xl md:text-3xl text-foreground">
                        {currentLessonContent.title}
                      </h2>
                    </div>

                    <Separator className="bg-border/30" />

                    {/* Lesson Content */}
                    <div className="prose prose-lg max-w-none">
                      <div className="font-zen-sans text-base text-muted-foreground leading-loose whitespace-pre-line space-y-6">
                        {currentLessonContent.content}
                      </div>
                    </div>

                    <Separator className="bg-border/30" />

                    {/* Reflection Section */}
                    <div className="space-y-6">
                      {!showReflection ? (
                        <button
                          onClick={() => setShowReflection(true)}
                          className="w-full text-center py-8 px-6 border border-border/50 rounded-lg hover:bg-muted/20 transition-colors group"
                        >
                          <Book className="h-6 w-6 text-muted-foreground/50 mx-auto mb-3 group-hover:text-primary/70 transition-colors" />
                          <p className="font-zen-serif text-base text-muted-foreground/70 group-hover:text-foreground transition-colors">
                            Bài suy ngẫm
                          </p>
                          <p className="font-zen-sans text-sm text-muted-foreground/50 mt-2">
                            Nhấn để xem
                          </p>
                        </button>
                      ) : (
                        <Card className="bg-muted/20 border-border/30">
                          <CardContent className="p-6 space-y-4">
                            <div className="flex items-center space-x-2">
                              <Book className="h-5 w-5 text-primary/70" />
                              <p className="font-zen-serif text-base text-foreground">
                                Bài suy ngẫm
                              </p>
                            </div>
                            <div className="font-zen-sans text-base text-muted-foreground leading-loose whitespace-pre-line italic">
                              {currentLessonContent.reflection}
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>

                    {/* Navigation */}
                    <div className="flex items-center justify-between pt-6">
                      <Button
                        variant="outline"
                        onClick={handlePrevious}
                        disabled={currentLessonId === 1}
                        className="font-zen-serif tracking-wider border-border/50 hover:bg-muted/30"
                      >
                        <ChevronLeft className="h-4 w-4 mr-2" />
                        Bài trước
                      </Button>

                      <Button
                        onClick={handleNext}
                        disabled={currentLessonId === lessons.length}
                        className="font-zen-serif tracking-wider bg-primary hover:bg-primary/90"
                      >
                        Bài sau
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>

      <ZenFooter />
    </div>
  )
}
