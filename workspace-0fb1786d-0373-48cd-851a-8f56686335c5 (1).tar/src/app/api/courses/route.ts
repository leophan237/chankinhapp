import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/courses - Get all courses with optional filtering
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const featured = searchParams.get('featured')
    const search = searchParams.get('search')

    const where: any = {}

    if (category && category !== 'Tất cả') {
      where.category = category
    }

    if (featured === 'true') {
      where.featured = true
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const courses = await db.course.findMany({
      where,
      include: {
        lessons: {
          orderBy: { order: 'asc' },
        },
        _count: {
          select: { enrollments: true },
        },
      },
      orderBy: { order: 'asc' },
    })

    return NextResponse.json({ courses })
  } catch (error) {
    console.error('Error fetching courses:', error)
    return NextResponse.json(
      { error: 'Failed to fetch courses' },
      { status: 500 }
    )
  }
}

// POST /api/courses - Create a new course (admin only)
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      title,
      subtitle,
      description,
      category,
      duration,
      level,
      image,
      quote,
      featured = false,
      order = 0,
    } = body

    if (!title || !description || !category) {
      return NextResponse.json(
        { error: 'Title, description, and category are required' },
        { status: 400 }
      )
    }

    const course = await db.course.create({
      data: {
        title,
        subtitle,
        description,
        category,
        duration,
        level,
        image,
        quote,
        featured,
        order,
      },
    })

    return NextResponse.json({ course }, { status: 201 })
  } catch (error) {
    console.error('Error creating course:', error)
    return NextResponse.json(
      { error: 'Failed to create course' },
      { status: 500 }
    )
  }
}
