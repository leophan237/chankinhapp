import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/comments - Get comments for a discussion
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const discussionId = searchParams.get('discussionId')
    const userId = searchParams.get('userId')

    const where: any = {}

    if (discussionId) {
      where.discussionId = discussionId
    }

    if (userId) {
      where.userId = userId
    }

    const comments = await db.comment.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            initials: true,
          },
        },
      },
      orderBy: { createdAt: 'asc' },
    })

    return NextResponse.json({ comments })
  } catch (error) {
    console.error('Error fetching comments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch comments' },
      { status: 500 }
    )
  }
}

// POST /api/comments - Create a new comment
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { discussionId, userId, content } = body

    if (!discussionId || !userId || !content) {
      return NextResponse.json(
        { error: 'Discussion ID, user ID, and content are required' },
        { status: 400 }
      )
    }

    // Verify discussion exists
    const discussion = await db.discussion.findUnique({
      where: { id: discussionId },
    })

    if (!discussion) {
      return NextResponse.json(
        { error: 'Discussion not found' },
        { status: 404 }
      )
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const comment = await db.comment.create({
      data: {
        discussionId,
        userId,
        content,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            initials: true,
          },
        },
      },
    })

    return NextResponse.json({ comment }, { status: 201 })
  } catch (error) {
    console.error('Error creating comment:', error)
    return NextResponse.json(
      { error: 'Failed to create comment' },
      { status: 500 }
    )
  }
}

// DELETE /api/comments - Delete a comment
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const commentId = searchParams.get('commentId')
    const userId = searchParams.get('userId')

    if (!commentId) {
      return NextResponse.json(
        { error: 'Comment ID is required' },
        { status: 400 }
      )
    }

    // Verify ownership
    const comment = await db.comment.findUnique({
      where: { id: commentId },
    })

    if (!comment) {
      return NextResponse.json(
        { error: 'Comment not found' },
        { status: 404 }
      )
    }

    // Check if user owns the comment (optional - can be removed if admin can delete)
    if (userId && comment.userId !== userId) {
      return NextResponse.json(
        { error: 'Unauthorized to delete this comment' },
        { status: 403 }
      )
    }

    await db.comment.delete({
      where: { id: commentId },
    })

    return NextResponse.json({ message: 'Comment deleted successfully' })
  } catch (error) {
    console.error('Error deleting comment:', error)
    return NextResponse.json(
      { error: 'Failed to delete comment' },
      { status: 500 }
    )
  }
}
