import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/progress - Get user's progress across all courses
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const enrollmentId = searchParams.get('enrollmentId')
    const lessonId = searchParams.get('lessonId')

    const where: any = {}

    if (userId) {
      // Get all progress for a user through enrollments
      const enrollments = await db.enrollment.findMany({
        where: { userId },
        select: { id: true },
      })

      where.enrollmentId = {
        in: enrollments.map((e) => e.id),
      }
    }

    if (enrollmentId) {
      where.enrollmentId = enrollmentId
    }

    if (lessonId) {
      where.lessonId = lessonId
    }

    const progress = await db.lessonProgress.findMany({
      where,
      include: {
        lesson: true,
        enrollment: {
          include: {
            course: true,
          },
        },
      },
      orderBy: { completedAt: 'desc' },
    })

    return NextResponse.json({ progress })
  } catch (error) {
    console.error('Error fetching progress:', error)
    return NextResponse.json(
      { error: 'Failed to fetch progress' },
      { status: 500 }
    )
  }
}

// POST /api/progress - Update or create progress
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { enrollmentId, lessonId, completed } = body

    if (!enrollmentId || !lessonId) {
      return NextResponse.json(
        { error: 'Enrollment ID and Lesson ID are required' },
        { status: 400 }
      )
    }

    // Check if enrollment exists
    const enrollment = await db.enrollment.findUnique({
      where: { id: enrollmentId },
    })

    if (!enrollment) {
      return NextResponse.json(
        { error: 'Enrollment not found' },
        { status: 404 }
      )
    }

    // Check if progress already exists
    const existingProgress = await db.lessonProgress.findUnique({
      where: {
        enrollmentId_lessonId: {
          enrollmentId,
          lessonId,
        },
      },
    })

    let progress

    if (existingProgress) {
      // Update existing progress
      progress = await db.lessonProgress.update({
        where: {
          enrollmentId_lessonId: {
            enrollmentId,
            lessonId,
          },
        },
        data: {
          completed: completed ?? true,
          completedAt: completed ? new Date() : null,
        },
        include: {
          lesson: true,
        },
      })
    } else {
      // Create new progress
      progress = await db.lessonProgress.create({
        data: {
          enrollmentId,
          lessonId,
          completed: completed ?? true,
          completedAt: completed ? new Date() : null,
        },
        include: {
          lesson: true,
        },
      })
    }

    // Check if all lessons in course are completed
    const allProgress = await db.lessonProgress.findMany({
      where: { enrollmentId },
      include: {
        lesson: true,
      },
    })

    // Get total lessons in course
    const courseEnrollment = await db.enrollment.findUnique({
      where: { id: enrollmentId },
      include: {
        course: {
          include: {
            _count: {
              select: { lessons: true },
            },
          },
        },
      },
    })

    if (courseEnrollment?.course?._count?.lessons) {
      const completedCount = allProgress.filter((p) => p.completed).length
      const totalLessons = courseEnrollment.course._count.lessons

      // Mark enrollment as completed if all lessons are done
      if (completedCount === totalLessons && totalLessons > 0) {
        await db.enrollment.update({
          where: { id: enrollmentId },
          data: { completedAt: new Date() },
        })
      }
    }

    return NextResponse.json({ progress })
  } catch (error) {
    console.error('Error updating progress:', error)
    return NextResponse.json(
      { error: 'Failed to update progress' },
      { status: 500 }
    )
  }
}

// DELETE /api/progress - Delete progress record
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const enrollmentId = searchParams.get('enrollmentId')
    const lessonId = searchParams.get('lessonId')

    if (!enrollmentId || !lessonId) {
      return NextResponse.json(
        { error: 'Enrollment ID and Lesson ID are required' },
        { status: 400 }
      )
    }

    await db.lessonProgress.deleteMany({
      where: {
        enrollmentId,
        lessonId,
      },
    })

    return NextResponse.json({ message: 'Progress deleted successfully' })
  } catch (error) {
    console.error('Error deleting progress:', error)
    return NextResponse.json(
      { error: 'Failed to delete progress' },
      { status: 500 }
    )
  }
}
