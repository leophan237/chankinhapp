import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/discussions - Get all discussions with optional filtering
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const userId = searchParams.get('userId')
    const search = searchParams.get('search')

    const where: any = {}

    if (category && category !== 'Tất cả') {
      where.category = category
    }

    if (userId) {
      where.userId = userId
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { content: { contains: search, mode: 'insensitive' } },
      ]
    }

    const discussions = await db.discussion.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            initials: true,
          },
        },
        _count: {
          select: { comments: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ discussions })
  } catch (error) {
    console.error('Error fetching discussions:', error)
    return NextResponse.json(
      { error: 'Failed to fetch discussions' },
      { status: 500 }
    )
  }
}

// POST /api/discussions - Create a new discussion
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, title, content, category } = body

    if (!userId || !title || !content || !category) {
      return NextResponse.json(
        { error: 'User ID, title, content, and category are required' },
        { status: 400 }
      )
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const discussion = await db.discussion.create({
      data: {
        userId,
        title,
        content,
        category,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            initials: true,
          },
        },
        _count: {
          select: { comments: true },
        },
      },
    })

    return NextResponse.json({ discussion }, { status: 201 })
  } catch (error) {
    console.error('Error creating discussion:', error)
    return NextResponse.json(
      { error: 'Failed to create discussion' },
      { status: 500 }
    )
  }
}
