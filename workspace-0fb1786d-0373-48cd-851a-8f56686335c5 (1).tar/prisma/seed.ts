import { db } from '../src/lib/db'

async function seed() {
  console.log('🌱 Seeding Chân Kinh Online database...\n')

  try {
    // Clear existing data
    await db.comment.deleteMany()
    await db.discussion.deleteMany()
    await db.lessonProgress.deleteMany()
    await db.enrollment.deleteMany()
    await db.lesson.deleteMany()
    await db.course.deleteMany()
    await db.user.deleteMany()

    console.log('✅ Cleared existing data\n')

    // Create sample users
    const users = await Promise.all([
      db.user.create({
        data: {
          email: 'minh@example.com',
          name: 'Thiền sinh Minh',
          initials: 'TM',
        },
      }),
      db.user.create({
        data: {
          email: 'hue@example.com',
          name: 'Người học đường',
          initials: 'NHD',
        },
      }),
      db.user.create({
        data: {
          email: 'tuan@example.com',
          name: 'Tâm Bất Biến',
          initials: 'TB',
        },
      }),
      db.user.create({
        data: {
          email: 'lan@example.com',
          name: 'Sinh viên',
          initials: 'SV',
        },
      }),
      db.user.create({
        data: {
          email: 'phuong@example.com',
          name: 'Trên con đường',
          initials: 'T',
        },
      }),
    ])

    console.log(`✅ Created ${users.length} users\n`)

    // Create sample courses
    const courses = await Promise.all([
      db.course.create({
        data: {
          title: 'Đạo Đức Kinh',
          subtitle: 'Kinh điển cơ bản',
          description:
            'Khởi hành từ những lời dạy cơ bản về đạo đức và lối sống. Một hành trình khám phá bản chất của tâm trí và hành vi con người.',
          category: 'Kinh điển',
          duration: '8 tuần',
          level: 'Nhập môn',
          quote: 'Học để hiểu, hiểu để hành, hành để chứng',
          featured: true,
          order: 1,
        },
      }),
      db.course.create({
        data: {
          title: 'Thiền Định Nhập Môn',
          subtitle: 'Thực hành tâm linh',
          description:
            'Học cách an trú trong hiện tại và phát triển sự tỉnh thức. Những kỹ thuật thiền định cơ bản cho người mới bắt đầu.',
          category: 'Thực hành',
          duration: '6 tuần',
          level: 'Nhập môn',
          featured: true,
          order: 2,
        },
      }),
      db.course.create({
        data: {
          title: 'Bát Chánh Đạo',
          subtitle: 'Hành trình giác ngộ',
          description:
            'Mười sáu bài học về con đường Trung Đạo. Một hệ thống hoàn chỉnh để hiểu rõ bản chất của khổ đau và sự giải thoát.',
          category: 'Kinh điển',
          duration: '16 tuần',
          level: 'Trung cấp',
          featured: true,
          order: 3,
        },
      }),
      db.course.create({
        data: {
          title: 'Kinh Dược Sư',
          subtitle: 'Hành trình chữa lành',
          description:
            'Khám phá sức mạnh chữa lành của tâm thức qua những lời dạy của Kinh Dược Sư Lưu Li Quang Vương.',
          category: 'Kinh điển',
          duration: '12 tuần',
          level: 'Nhập môn',
          featured: false,
          order: 4,
        },
      }),
      db.course.create({
        data: {
          title: 'Chánh Niệm Trong Cuộc Sống',
          subtitle: 'Thực hành hàng ngày',
          description:
            'Áp dụng chánh niệm vào các hoạt động thường ngày: ăn uống, đi lại, làm việc. Tìm kiếm sự bình an trong từng khoảnh khắc.',
          category: 'Thực hành',
          duration: '4 tuần',
          level: 'Nhập môn',
          featured: false,
          order: 5,
        },
      }),
      db.course.create({
        data: {
          title: 'Kinh Kim Cương',
          subtitle: 'Bản chất của sự thật',
          description:
            'Một trong những kinh văn quan trọng nhất của Đại thừa. Giải mã bản chất không và sự thật tuyệt đối.',
          category: 'Kinh điển',
          duration: '20 tuần',
          level: 'Trung cấp',
          featured: false,
          order: 6,
        },
      }),
      db.course.create({
        data: {
          title: 'Biết Trả Lời',
          subtitle: 'Giao tiếp tỉnh thức',
          description:
            'Học cách lắng nghe sâu và phản hồi với từ ngữ yêu thương. Kỹ năng giao tiếp trong các mối quan hệ.',
          category: 'Thực hành',
          duration: '5 tuần',
          level: 'Nhập môn',
          featured: false,
          order: 7,
        },
      }),
      db.course.create({
        data: {
          title: 'Kinh Hoa Nghiêm',
          subtitle: 'Vũ trụ tâm thức',
          description:
            'Mở rộng hiểu biết về thế giới qua lăng kính của Kinh Hoa Nghiêm. Mối quan hệ tương giao giữa mọi sự vật.',
          category: 'Kinh điển',
          duration: '24 tuần',
          level: 'Trung cấp',
          featured: false,
          order: 8,
        },
      }),
      db.course.create({
        data: {
          title: 'Nuôi Dưỡng Từ Bi',
          subtitle: 'Tâm từ bi',
          description:
            'Trồng mầm từ bi trong tâm thức. Những thực hành đơn giản để nuôi dưỡng tình yêu thương vô điều kiện.',
          category: 'Thực hành',
          duration: '6 tuần',
          level: 'Nhập môn',
          featured: false,
          order: 9,
        },
      }),
    ])

    console.log(`✅ Created ${courses.length} courses\n`)

    // Create lessons for course 1 (Đạo Đức Kinh)
    await Promise.all([
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Đạo là gì?',
          section: 'Phần 1: Nhập môn',
          duration: '15 phút',
          order: 1,
          content:
            'Đạo không phải là một khái niệm trừu tượng, mà là con đường của sự thực. Khi chúng ta đi trên con đường này, chúng ta không đi đến một đích đến xa xôi, mà đi sâu vào chính thực tại của mình.\n\nĐạo là sự hòa hợp, là sự cân bằng, là sự hiểu biết sâu sắc về bản chất của sự vật.',
          reflection:
            'Hãy ngồi yên một chút và tự hỏi: Đối với tôi, Đạo có nghĩa là gì?',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Bản chất của tâm',
          section: 'Phần 1: Nhập môn',
          duration: '20 phút',
          order: 2,
          content:
            'Tâm là nơi khởi đầu của mọi hành động. Khi tâm an định, hành động sẽ an định. Khi tâm hỗn loạn, hành động cũng hỗn loạn.\n\nHiểu về tâm là bước đầu tiên trong hành trình tu tập.',
          reflection:
            'Quan sát tâm của bạn trong vài phút. Không phán xét, chỉ quan sát.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Ý nghĩa của đạo đức',
          section: 'Phần 1: Nhập môn',
          duration: '18 phút',
          order: 3,
          content:
            'Đạo đức không phải là một tập hợp các quy tắc hay kỷ luật cứng nhắc. Nó là sự hiểu biết sâu sắc về bản chất của sự vật và mối quan hệ giữa chúng.',
          reflection:
            'Hãy suy ngẫm về những hành động đạo đức mà bạn đã thực hành trong quá khứ.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Thân',
          section: 'Phần 2: Thực hành',
          duration: '25 phút',
          order: 4,
          content:
            'Thân là phương tiện để chúng ta trải nghiệm và học hỏi. Caring cho thân là một hình thức của thực hành.',
          reflection:
            'Thực hành chánh niệm với thân trong 10 phút. Quan sát từng hơi thở, từng cử động.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Khẩu',
          section: 'Phần 2: Thực hành',
          duration: '22 phút',
          order: 5,
          content:
            'Lời nói có sức mạnh. Chúng có thể chữa lành hoặc làm tổn thương. Chánh niệm trong lời nói là một thực hành quan trọng.',
          reflection:
            'Trong một ngày, hãy quan sát những gì bạn nói. Hãy nói những lời yêu thương.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Ý',
          section: 'Phần 2: Thực hành',
          duration: '30 phút',
          order: 6,
          content:
            'Ý định đằng sau hành động quan trọng hơn chính hành động. Khi ý định trong sáng, hành động sẽ mang lại kết quả tốt đẹp.',
          reflection:
            'Trước khi làm điều gì, hãy kiểm tra ý định của mình. Tôi làm vì điều gì?',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Sống tỉnh thức',
          section: 'Phần 2: Thực hành',
          duration: '28 phút',
          order: 7,
          content:
            'Sống tỉnh thức là sống trong hiện tại, không bị kéo về quá khứ hay tương lai. Mỗi khoảnh khắc là một cơ hội để thực hành.',
          reflection:
            'Hãy chọn một hoạt động hàng ngày và thực hành nó với sự tỉnh thức hoàn toàn.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Gặp khó khăn',
          section: 'Phần 3: Củng cố',
          duration: '20 phút',
          order: 8,
          content:
            'Khó khăn là một phần của hành trình. Khi gặp trở ngại, thay vì bỏ cuộc, hãy nhìn vào nó như một cơ hội để học.',
          reflection:
            'Hãy nghĩ về một khó khăn bạn đang gặp. Bạn có thể học được gì từ nó?',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Kiên trì',
          section: 'Phần 3: Củng cố',
          duration: '25 phút',
          order: 9,
          content:
            'Kiên trì không phải là tiếp tục làm điều gì đó theo thói quen, mà là tiếp tục vì bạn hiểu ý nghĩa của nó.',
          reflection:
            'Có những thực hành nào bạn muốn kiên trì theo đuổi? Tại sao?',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[0].id,
          title: 'Tiếp tục hành trình',
          section: 'Phần 3: Củng cố',
          duration: '30 phút',
          order: 10,
          content:
            'Khóa học này chỉ là một bước trong hành trình dài. Quan trọng hơn là bạn tiếp tục thực hành sau khi khóa học kết thúc.',
          reflection:
            'Lập một kế hoạch thực hành cho tháng tới. Bạn sẽ thực hành như thế nào?',
        },
      }),
    ])

    // Create lessons for course 2 (Thiền Định Nhập Môn)
    await Promise.all([
      db.lesson.create({
        data: {
          courseId: courses[1].id,
          title: 'Giới thiệu về thiền định',
          section: 'Phần 1: Nhập môn',
          duration: '15 phút',
          order: 1,
          content:
            'Thiền định là thực hành an trú tâm trí. Không phải để trở thành người khác, mà để trở thành chính mình.',
          reflection: 'Hãy ngồi yên trong 5 phút và quan sát hơi thở.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[1].id,
          title: 'Tư thế thiền',
          section: 'Phần 1: Nhập môn',
          duration: '20 phút',
          order: 2,
          content:
            'Tư thế đúng giúp tâm trí an định. Học cách ngồi với sự tôn trọng và chăm sóc.',
          reflection: 'Thực hành tư thế thiền đúng trong 10 phút.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[1].id,
          title: 'Thở chánh niệm',
          section: 'Phần 2: Thực hành',
          duration: '25 phút',
          order: 3,
          content:
            'Hơi thở là cầu nối giữa thân và tâm. Khi quan sát hơi thở, chúng ta thực hiện chánh niệm.',
          reflection: 'Quan sát 10 hơi thở đầy đủ.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[1].id,
          title: 'Quan sát suy nghĩ',
          section: 'Phần 2: Thực hành',
          duration: '30 phút',
          order: 4,
          content:
            'Suy nghĩ tự nhiên đến và đi. Không cần ngăn chúng lại, chỉ cần quan sát.',
          reflection: 'Quan sát những suy nghĩ xuất hiện trong 15 phút.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[1].id,
          title: 'Tiếp tục thực hành',
          section: 'Phần 3: Củng cố',
          duration: '20 phút',
          order: 5,
          content:
            'Thiền định không phải là một lần thực hành, mà là một thói quen hàng ngày.',
          reflection: 'Lập kế hoạch thực hành thiền hàng tuần.',
        },
      }),
      db.lesson.create({
        data: {
          courseId: courses[1].id,
          title: 'Áp dụng vào cuộc sống',
          section: 'Phần 3: Củng cố',
          duration: '25 phút',
          order: 6,
          content:
            'Tâm thức thiền không chỉ khi ngồi trên đệm, mà trong mọi hoạt động hàng ngày.',
          reflection: 'Chọn một hoạt động và thực hành nó với chánh niệm.',
        },
      }),
    ])

    console.log('✅ Created lessons for courses\n')

    // Create some enrollments
    await Promise.all([
      db.enrollment.create({
        data: {
          userId: users[0].id,
          courseId: courses[0].id,
        },
      }),
      db.enrollment.create({
        data: {
          userId: users[0].id,
          courseId: courses[1].id,
        },
      }),
      db.enrollment.create({
        data: {
          userId: users[1].id,
          courseId: courses[0].id,
        },
      }),
      db.enrollment.create({
        data: {
          userId: users[2].id,
          courseId: courses[2].id,
        },
      }),
    ])

    console.log('✅ Created enrollments\n')

    // Create some sample discussions
    await Promise.all([
      db.discussion.create({
        data: {
          userId: users[0].id,
          title: 'Làm thế nào để duy trì sự tỉnh thức trong công việc bận rộn?',
          content:
            'Mình đã thử nhiều cách nhưng vẫn thường xuyên quên mất sự tỉnh thức khi công việc quá tải. Có ai có kinh nghiệm chia sẻ không?',
          category: 'Thực hành',
          likes: 24,
        },
      }),
      db.discussion.create({
        data: {
          userId: users[1].id,
          title: 'Hành trình với Đạo Đức Kinh',
          content:
            'Đang học bài thứ 3 và cảm thấy thay đổi dần dần. Có ai đang học khóa này không? Cùng chia sẻ kinh nghiệm nhé.',
          category: 'Kinh điển',
          likes: 19,
        },
      }),
      db.discussion.create({
        data: {
          userId: users[2].id,
          title: 'Sự khác biệt giữa hiểu và chứng',
          content:
            'Mình đang suy ngẫm về sự khác biệt giữa hiểu bằng lý trí và thực chứng từ kinh nghiệm. Rất mong nhận được góc nhìn từ mọi người.',
          category: 'Triết lý',
          likes: 32,
        },
      }),
      db.discussion.create({
        data: {
          userId: users[3].id,
          title: 'Lịch sử Chân Kinh Online',
          content:
            'Mình mới gia nhập và rất tò mò về nguồn gốc và lịch sử phát triển của nền tảng này. Có ai biết không ạ?',
          category: 'Tổng quan',
          likes: 14,
        },
      }),
      db.discussion.create({
        data: {
          userId: users[4].id,
          title: 'Gặp khó khăn khi thực hành chánh niệm',
          content:
            'Đôi khi mình cảm thấy thực hành càng khó hơn thay vì dễ hơn. Đây có phải là dấu hiệu bình thường không?',
          category: 'Thực hành',
          likes: 28,
        },
      }),
    ])

    console.log('✅ Created discussions\n')

    console.log('🌸 Seeding completed successfully!\n')
  } catch (error) {
    console.error('❌ Error seeding database:', error)
    process.exit(1)
  } finally {
    await db.$disconnect()
  }
}

seed()
